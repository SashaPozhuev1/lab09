#include <string>
#include <fstream>
#include <iostream>

void print(const std::string& text, std::ostream& out = std::cout);//функция выводит строку в поток 
void print(const std::string& text, std::ofstream& out);//функция выводит строку в файл

